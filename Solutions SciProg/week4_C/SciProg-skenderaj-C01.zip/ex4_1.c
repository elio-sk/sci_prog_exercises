#include <stdio.h>

main() {
int a=0; int b=0;

printf("Input a=");
scanf("%d",&a);
printf("Input b=");
scanf("%d",&b);

double m= (double) (a+b)/2;
printf("Mean is m=%f\n",m);

}

