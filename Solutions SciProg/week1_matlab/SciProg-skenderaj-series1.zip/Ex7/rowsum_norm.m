function n=rowsum_norm(A)
    n=max(sum(abs(A(:,1:end))));
end